from django.conf.urls import include,url

from . import views

urlpatterns = [
    url('main/', views.main, name='main'),
]